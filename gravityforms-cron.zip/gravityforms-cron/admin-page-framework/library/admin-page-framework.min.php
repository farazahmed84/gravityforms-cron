<?php 
/**
 Admin Page Framework - Minified Version v3.5.4 by Michael Uno 
 @deprecated 3.5.4 Use the component generator instead. 
 Go to Dashboard -> Admin Page Framework -> Tools -> Generator and generate your own version of the framework.
 @remark        This file will be kept for backward compatibility for a while for some users who have been directly including this file.
 */
trigger_error( 
    'Admin Page Framework:'
        . ' The minified version is deprecated.'
        . ' Use the component generator instead available at Dashboard -> Admin Page Framework -> Tools -> Generator.',
    E_USER_WARNING 
);
include( dirname( __FILE__ ) . '/apf/admin-page-framework.php' );
