=== Plugin Name ===
Plugin Name: Gravity Forms Delayed Notifications
Plugin URI: http://www.zewlak.com/gfc
Description: Add-on for Gravity Forms to send delayed notifications
Version: 1.0
Author: Tomasz Zewlakow
Author URI: http://www.zewlak.com

== Description ==

Plugin to send delayed notifications after form submission.

== Installation ==

1. Upload zip content to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. See new `Delayed notifications` submenu in `Forms` menu option

== Frequently Asked Questions ==

Nothing here yet

== Changelog ==
= 1.0 =
* Release version

